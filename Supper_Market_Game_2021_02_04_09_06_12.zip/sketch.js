var boy;
function setup() {
  createCanvas(400, 400);
  boy = createSprite(200,200,30,30);
}

function draw() {
  background(220);
  
  
  
  
  
  drawSprites();
}